
package prog;

import javax.swing.JOptionPane;
import java.util. *;
import java.util.regex.Pattern;



public class PROG {

    
    public static void main(String[] args) {
        String firstname;
        String lastname;
        String username;
        String passwaord;
                
        JOptionPane.showMessageDialog(null, "Enter your first name");
        JOptionPane.showInputDialog("");
        JOptionPane.showMessageDialog(null, "Enter your last name");
        JOptionPane.showInputDialog("");
        JOptionPane.showMessageDialog(null, "Enter username");
        JOptionPane.showInputDialog("");
        JOptionPane.showMessageDialog(null, "Enter your passwaord");
        JOptionPane.showInputDialog("");
        
        String input = "username";
        
        if(isWord(input))
        {
          JOptionPane.showMessageDialog(null, "Username is captured successfully"); 
        }
        else
        {
            JOptionPane.showMessageDialog(null, "Username is not correctly formatted,"
                    + " please ensure that your username contains an underscore and is no more than 5 characters in length");
        }
            
    }
    
    public static boolean isWord(String in){
        return Pattern.matches("(a-zA-Z)+ underscore+ not > 5 characters", in);
        
    
        
        
        
   
        
        
        
        
       
        
        
    }
    
}
